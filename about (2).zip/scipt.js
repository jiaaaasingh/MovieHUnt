// document.addEventListener('DOMContentLoaded', function () {
//     var searchInput = document.querySelector('.search-input');
//     var searchIcon = document.querySelector('.search-icon');

//     function adjustPanel2() {
//         if (window.innerWidth <= 768) {
//             // Adjust the search input for smaller screens
//             searchInput.style.width = 'calc(100% - 40px)';
//             searchInput.style.paddingRight = '40px'; // To make space for the search icon inside the input
//             searchIcon.style.display = 'block';
//             searchIcon.style.position = 'absolute';
//             searchIcon.style.right = '10px';
//             searchIcon.style.top = '50%';
//             searchIcon.style.transform = 'translateY(-50%)';
//         } else {
//             // Adjust the search input for larger screens
//             searchInput.style.width = '300px';
//             searchInput.style.paddingRight = '0';
//             searchIcon.style.display = 'inline-block';
//             searchIcon.style.position = 'absolute';
//             searchIcon.style.left = '310px'; // 300px + 10px margin
//             searchIcon.style.top = '50%';
//             searchIcon.style.transform = 'translateY(-50%)';
//         }
//     }

//     // Initial adjustment
//     adjustPanel2();

//     // Adjust on window resize
//     window.addEventListener('resize', adjustPanel2);
// });

document.getElementsByClassName("thriller", thrillerContent())
{}
